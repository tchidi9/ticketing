# GestSup Security

If you find security problem, thanks to report directly by mail. 
Send an encrypted zip with password on contact AT gestsup DOT fr and send password only on gestsup AT yopmail DOT COM

# GestSup Bug

Please report other bug type directly on https://gestsup.fr/forum/viewforum.php?f=1

Thanks for your help! 