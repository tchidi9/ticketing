﻿-- Update GestSup version
update tparameters set version='1.4';
-- -----------------------------