<?php
	define("_lang_access_error", "You do not have access rights to this section, contact your administrator");
	define("_lang_it_availability", "Availability of the Information System");
?>