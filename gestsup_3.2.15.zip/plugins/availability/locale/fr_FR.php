<?php
	define("_lang_access_error", "Vous n'avez pas les droits d'accès à cette section, contacter votre administrateur");
	define("_lang_it_availability", "Disponibilité du Système d'information");
?>