<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<style type="text/css">@media screen and (max-width: 980px) {body{font-size: 18px}}</style>
#################################<br />
# @Name :  Plugin Release Notes   <br />
# @Date : 12/01/2021             <br />
# @Version : 1.0    	 	     <br />
#################################<br />
<br />
<u>Description :</u><br />
- Affiche une nouvelle section dans le menu permettant d'afficher des statistiques sur les niveaux de disponibilité par catégorie<br />
