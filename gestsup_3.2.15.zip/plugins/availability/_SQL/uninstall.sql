SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET default_storage_engine=INNODB;

DELETE FROM  `tplugins` WHERE `name`='availability';